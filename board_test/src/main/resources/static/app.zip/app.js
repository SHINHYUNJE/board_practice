// App.js
Ext.application({
    name: 'App',

    // 애플리케이션에 필요한 클래스를 미리 로드합니다.
    requires: [
        'App.model.Board',
        'App.store.Boards',
        'App.view.BoardList',
        'App.view.BoardDetail',
        'App.view.BoardEdit',
        'App.controller.BoardController'
    ],

    // 애플리케이션의 메인 뷰를 지정합니다. 
    // 이 뷰는 애플리케이션이 시작될 때 자동으로 생성되고, 화면에 표시됩니다.
    mainView: 'App.view.BoardList',

    // 애플리케이션 시작 시 실행할 코드를 정의합니다.
    launch: function () {
        // 서버에서 초기 데이터를 로드하거나, 필요한 초기화 작업을 수행할 수 있습니다.
        // 게시글 목록 그리드 생성 및 렌더링
        Ext.create('App.view.BoardList', {
            renderTo: Ext.getBody() // 현재는 body에 직접 렌더링하도록 설정했습니다. 필요에 따라 조절하세요.
        });
    }
});
