Ext.define('App.controller.BoardController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.board',

    // 초기화 함수에서 이벤트 핸들러를 정의합니다.
    init: function() {
        this.control({
            'boardlist': {
                itemdblclick: this.showBoardDetail
            },
            'boardlist button[action=delete]': {
                click: this.deleteBoard
            },
            'boardedit button[action=save]': {
                click: this.saveOrUpdateBoard
            }
        });
    },

    // 게시글 상세 정보를 보여주는 창을 여는 함수
    showBoardDetail: function(grid, record) {
        var detailWindow = Ext.create('App.view.BoardDetail', {
            viewModel: {
                data: {
                    board: record.getData()
                }
            }
        });
        detailWindow.show();
    },

    // 선택된 게시글을 삭제하는 함수
    deleteBoard: function(button) {
        var grid = this.getView(),
            selection = grid.getSelectionModel().getSelection();

        if (selection.length) {
            Ext.Msg.confirm('Confirm', 'Are you sure you want to delete this board?', function(answer) {
                if (answer === 'yes') {
                    var record = selection[0];
                    Ext.Ajax.request({
                        url: '/api/boards/' + record.get('boardSn'),
                        method: 'DELETE',
                        success: function(response) {
                            Ext.Msg.alert('Success', 'Board deleted successfully.');
                            grid.getStore().remove(record);
                            grid.getStore().reload();
                        },
                        failure: function(response) {
                            Ext.Msg.alert('Error', 'Failed to delete board.');
                        }
                    });
                }
            });
        } else {
            Ext.Msg.alert('Warning', 'Please select a board to delete.');
        }
    },

    // 게시글을 저장하거나 업데이트하는 함수
    saveOrUpdateBoard: function(button) {
        var window = button.up('window'),
            form = window.down('form'),
            isEdit = !!form.getRecord(),
            url = '/api/boards' + (isEdit ? '/' + form.getRecord().get('boardSn') : ''),
            method = isEdit ? 'PUT' : 'POST';

        Ext.Ajax.request({
            url: url,
            method: method,
            jsonData: form.getValues(),
            success: function(response) {
                Ext.Msg.alert('Success', 'Board ' + (isEdit ? 'updated' : 'created') + ' successfully.');
                window.close();
                Ext.getStore('Boards').reload();
            },
            failure: function(response) {
                Ext.Msg.alert('Error', 'Failed to ' + (isEdit ? 'update' : 'create') + ' board.');
            }
        });
    }
});
