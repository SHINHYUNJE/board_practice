Ext.define('App.store.Boards', {
    extend: 'Ext.data.Store',
    model: 'App.model.Board',
    autoLoad: true,
    proxy: {
        type: 'ajax',
        url: '/api/boards', // 서버의 엔드포인트 URL
        reader: {
            type: 'json',
            rootProperty: 'data'
        },
        writer: {
            type: 'json'
        }
    }
});
