Ext.define('App.model.Board', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'boardSn', type: 'int' },
        { name: 'title', type: 'string' },
        { name: 'content', type: 'string' },
        { name: 'author', type: 'string' },
        { name: 'createdAt', type: 'date' }
    ]
});
