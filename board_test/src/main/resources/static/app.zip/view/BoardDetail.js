Ext.define('App.view.BoardDetail', {
    extend: 'Ext.window.Window',
    xtype: 'boarddetail',
    title: '게시글 상세',
    width: 400,
    layout: 'fit',
    autoShow: true,
    items: [{
        xtype: 'form',
        items: [
            { xtype: 'displayfield', fieldLabel: 'ID', name: 'boardSn' },
            { xtype: 'displayfield', fieldLabel: '제목', name: 'title' },
            { xtype: 'displayfield', fieldLabel: '작성자', name: 'author' },
            { xtype: 'displayfield', fieldLabel: '작성일', name: 'createdAt' },
            { xtype: 'textarea', fieldLabel: '내용', name: 'content', readOnly: true }
        ]
    }]
});
