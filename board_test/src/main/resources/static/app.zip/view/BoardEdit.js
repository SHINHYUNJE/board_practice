Ext.define('App.view.BoardEdit', {
    extend: 'Ext.window.Window',
    xtype: 'boardedit',
    title: '게시글 편집',
    width: 400,
    layout: 'fit',
    autoShow: true,
    items: [{
        xtype: 'form',
        items: [
            { xtype: 'textfield', fieldLabel: '제목', name: 'title' },
            { xtype: 'textfield', fieldLabel: '작성자', name: 'author' },
            { xtype: 'datefield', fieldLabel: '작성일', name: 'createdAt' },
            { xtype: 'textarea', fieldLabel: '내용', name: 'content' }
        ]
    }]
});