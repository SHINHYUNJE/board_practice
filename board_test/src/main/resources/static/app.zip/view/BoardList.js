Ext.define('App.view.BoardList', {
    extend: 'Ext.grid.Panel',
    xtype: 'boardlist',
    title: '게시글 목록',
    store: {
        type: 'boards'
    },
    columns: [
        { text: 'ID', dataIndex: 'boardSn', width: 50 },
        { text: '제목', dataIndex: 'title', flex: 1 },
        { text: '작성자', dataIndex: 'author', width: 200 },
        { text: '작성일', dataIndex: 'createdAt', width: 200 }
    ]
});
